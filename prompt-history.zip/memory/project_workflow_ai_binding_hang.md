---
name: project-workflow-ai-binding-hang
description: "RESOLVED — the run-analysis hang was wrangler-dev-local-only; confirmed working end to end (16.6s, 3 findings) against the real deployed Worker on 2026-08-30."
metadata: 
  node_type: memory
  type: project
  originSessionId: fd68bfd9-01de-47c3-b5b4-f2a4d3039cad
  modified: 2026-08-30T20:22:26.161Z
---

**Resolved 2026-08-30.** Confirmed against the real deployed Worker (`https://crypto-risk-agent.mack76801.workers.dev`, deployed by the user) that the full `ingestFindings` → `CryptoRiskWorkflow` → `completeAnalysis` pipeline completes correctly: 3 findings classified with real per-finding rationale/guidance, full report generated, state reached `complete` in 16.6s. This confirms the hang documented below was **entirely a `wrangler dev` local-emulation limitation** — how local dev proxies the remote `AI` binding into a Workflow step context — not a bug in `workflow.ts`, the model, or `workers-ai-provider`.

**How to apply:** Don't re-investigate this as a code issue. If a similar hang resurfaces, reproduce it via `wrangler dev` first to confirm it's still local-dev-only before assuming a regression in application code. `"remote": true` was added to the `ai` binding in `wrangler.jsonc` during the investigation — harmless, can stay. The idea of recreating `createWorkersAI` per `step.do()` call was investigated and ruled out as a real fix (see trail below) — don't revisit it.

<details>
Original investigation trail (kept for reference — useful if a related local-dev binding issue comes up):

Verified 2026-08-30: the "run analysis" flow (`ingestFindings` → `CryptoRiskWorkflow` → `completeAnalysis`) did **not** complete in local `wrangler dev` (wrangler 4.127.1). The `classify-<id>` step's `generateObject` call against the `AI` binding hung indefinitely — no response, no error, and the local Workflows engine didn't even fire its own step timeout/retry (confirmed stuck 12+ min past its declared 10-minute step timeout, with the `priority_queue` entry in `.wrangler/state/v3/workflows/.../*.sqlite` never processed).

Isolated via direct testing, ruling out each other layer:
- Direct REST call to `@cf/meta/llama-3.3-70b-instruct-fp8-fast` via curl: 200 OK in ~5s. Model is valid and responsive.
- `generateText`/`generateObject` (workers-ai-provider + `ai` SDK) called directly against the real Workers AI REST API, bypassing wrangler entirely: both succeeded in under 3s, including structured output via zod schema.
- `askQuestion` RPC — calls `generateText` against the same `AI` binding, but from inside the Agent's Durable Object (not a Workflow) in `wrangler dev`: succeeded in ~1.15s.
- `ingestFindings` RPC — same binding, same model, called from inside `CryptoRiskWorkflow`'s `step.do()`: hung indefinitely.

Checked 2026-08-30: no wrangler upgrade fixes this — 4.127.1 was already the latest npm release, and the two closest upstream issues (cloudflare/workers-sdk#10369, #8002) are both closed as stale/`needs-reproduction` with no maintainer workaround or fix PR.

Also checked 2026-08-30: added `"remote": true` explicitly to the `ai` binding in `wrangler.jsonc`. This was a real, partial change in behavior — with it, the *first* AI call issued inside a Workflow run succeeded (`classify-f1` returned a real result in ~4.2s), but the *second* sequential `step.do()` AI call in the same run (`classify-f2`) then hung the same way everything used to hang. Without `remote: true`, every AI call inside a Workflow hung immediately, 100% of the time.

Investigated whether this was `createWorkersAI` connection/instance reuse across `step.do()` calls (workflow.ts hoists one `createWorkersAI(...)` provider to the top of `run()` and reuses it across all steps). Read the actual `workers-ai-provider` source (`node_modules/workers-ai-provider/src/index.ts` and `workersai-chat-language-model.ts`): `createWorkersAI` performs zero I/O and holds no connection/session state — it's a synchronous closure over the `binding` reference. `WorkersAIChatLanguageModel` (the class that issues the actual request) holds only three plain readonly fields (`modelId`, `settings`, `config`) set at construction, nothing stateful. Critically, `workflow.ts` already constructs a fresh `WorkersAIChatLanguageModel` per `step.do()` call (`workersai(modelId)` is called inside the loop, once per finding) — only the outer provider closure is shared, and that closure was proven to hold no I/O-relevant state. So recreating `createWorkersAI` per step would not have changed anything; ruled out as a real fix before it was tried in code.

Root cause was therefore concluded to be in `wrangler dev`'s local emulation of the remote `AI` binding across Workflow step boundaries, not in application code — now confirmed correct by the successful production run.

Orphaned local dev state from the investigation lives in `.wrangler/state/v3/workflows/miniflare-workflows-crypto-risk-workflow/` (gitignored, harmless) — safe to ignore or delete that directory to reset local Workflow state if it causes confusion later.
</details>
